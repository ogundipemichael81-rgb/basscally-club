# Basscally Club — Landing Page Copy & Wireframe

**Page URL:** `basscally.club` (or `basscally.club/`)
**Goal:** Convert TikTok/Instagram visitor → paid subscriber in ≤ 3 clicks
**Target conversion rate:** 4–8% (cold social traffic)

---

## Wireframe (top to bottom)

```text
┌─────────────────────────────────────────────────────────────┐
│  [NAV] Basscally Club          [Login]  [Join — $1.50/mo]  │ ← Sticky
├─────────────────────────────────────────────────────────────┤
│                                                             │
│              🎸                                             │
│                                                             │
│        PRACTICE WITH BASSCALLY                              │
│           FOR $1.50/MONTH                                   │
│                                                             │
│   New bass-less covers, grooves, fills, and challenges      │
│            delivered every 3 days.                          │
│                                                             │
│         [ Join Basscally Club — $1.50/month ]              │ ← Primary CTA
│         Cancel anytime. No contracts.                       │
│                                                             │
│         ⭐ 90,000+ bassists already follow Basscally        │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│        WHAT YOU GET, EVERY 3 DAYS                           │
│                                                             │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐    │
│  │   🎧     │  │   🔁     │  │   ⚡     │  │   🎯     │    │
│  │ Bass-    │  │ Grooves  │  │ Fills    │  │ Weekly   │    │
│  │ less     │  │          │  │          │  │ Challenge│    │
│  │ Covers   │  │ Short    │  │ The      │  │          │    │
│  │          │  │ patterns │  │ trans-   │  │ A bass   │    │
│  │ Play the │  │ to lock  │  │ itions   │  │ goal to  │    │
│  │ songs    │  │ in your  │  │ that     │  │ hit this │    │
│  │ you see  │  │ pocket   │  │ make     │  │ week     │    │
│  │ us cover │  │          │  │ you      │  │          │    │
│  │ on TikTok│  │          │  │ sound    │  │          │    │
│  │          │  │          │  │ pro      │  │          │    │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘    │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│        HOW IT WORKS                                         │
│                                                             │
│   1️⃣  Join for $1.50/month                                  │
│   2️⃣  Get an email every 3 days when a new drop lands       │
│   3️⃣  Open the dashboard, download the audio, practice      │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│        WHO BASSCALLY IS FOR                                 │
│                                                             │
│   ✅ Self-taught bassists who want structure                │
│   ✅ Players who learned from TikTok and want to go deeper  │
│   ✅ Anyone tired of paying $20 for one masterclass         │
│   ✅ Bassists anywhere — Africa, UK, US, Asia, everywhere   │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│        SOCIAL PROOF                                         │
│                                                             │
│  "[insert real comment from TikTok]"  — @username           │
│  "[insert real comment]"              — @username           │
│  "[insert real comment]"              — @username           │
│                                                             │
│   [embed 2-3 TikTok views screenshots — 90k followers,     │
│    viral video stats, comment highlights]                   │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│        WHY $1.50?                                           │
│                                                             │
│  Because practice shouldn't cost a meal.                    │
│                                                             │
│  We built this for every bassist with internet, anywhere.   │
│  Cancel anytime. Keep what you've already downloaded.       │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│        FOUNDING MEMBER OFFER                                │
│                                                             │
│   First 500 members lock in $1.50/month for life.           │
│   After that, the price goes up.                            │
│                                                             │
│         [ Become a Founding Member — $1.50/month ]         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│        FAQ                                                  │
│                                                             │
│  ▸ What's in the Club?                                      │
│  ▸ How often do I get new content?                          │
│  ▸ Can I cancel anytime?                                    │
│  ▸ Do I need to be advanced?                                │
│  ▸ What if I'm not in the UK or US?                         │
│  ▸ Can I download the files?                                │
│  ▸ Is this taught by Chris?                                 │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│        FINAL CTA                                            │
│                                                             │
│         Stop scrolling. Start practicing.                   │
│                                                             │
│         [ Join Basscally Club — $1.50/month ]              │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  [Footer]                                                   │
│  Basscally Club  |  TikTok  |  Instagram  |  Contact        │
│  Terms  |  Privacy  |  © 2026                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Final Copy (use exactly as written, swap bracketed placeholders)

### Nav
- **Logo:** Basscally Club
- **Login** (right side)
- **Join — $1.50/mo** (button, right side, primary colour)

### Hero

**Eyebrow** (small, above headline, optional):
🎸 *The bass practice club*

**Headline:**
# Practice with Basscally for $1.50/month.

**Subheadline:**
New bass-less covers, grooves, fills, and challenges — delivered every 3 days.

**Primary CTA button:**
`Join Basscally Club — $1.50/month`

**Below CTA (small grey text):**
Cancel anytime. No contracts. No hidden upsells.

**Trust strip below:**
⭐ 90,000+ bassists already follow Basscally on TikTok

---

### Section 2 — What you get

**Heading:**
## What you get, every 3 days

**Card 1 — Bass-less Covers**
🎧 **Bass-less Covers**
The songs you see Chris cover on TikTok — without the bass. Drop in, play the part, sound huge.

**Card 2 — Grooves**
🔁 **Grooves**
Short, looped patterns to lock in your pocket. New ones every 3 days. Easy on day one, addictive by day ten.

**Card 3 — Fills**
⚡ **Fills**
The transitions that separate beginners from players. Steal them. Reuse them. Make them yours.

**Card 4 — Challenges**
🎯 **Weekly Challenges**
A bass goal to hit every week. Record it, share it, level up. Recognition in the Club.

---

### Section 3 — How it works

**Heading:**
## How it works

**Step 1:** Join the Club for $1.50/month.
**Step 2:** Get an email every 3 days when a new drop lands.
**Step 3:** Open the dashboard, download the audio, and practice.

That's it. No app to install. No course to finish. Just practice material in your inbox, forever.

---

### Section 4 — Who it's for

**Heading:**
## Who Basscally Club is for

- ✅ Self-taught bassists who want structure without a teacher
- ✅ Players who learned the basics on TikTok and are ready to go deeper
- ✅ Anyone who's tired of paying $20 for a single masterclass
- ✅ Bassists anywhere on Earth — Africa, UK, US, Asia, Latin America, Europe

**Heading (smaller):**
### Who it's NOT for
- ❌ People who want a structured curriculum from beginner to pro
- ❌ Players looking for one-on-one lessons (we'll have that later)
- ❌ Anyone who doesn't actually want to practice

---

### Section 5 — Social proof

**Heading:**
## Real bassists. Real progress.

*[Pull 3 real, verbatim comments from TikTok/Instagram — pick ones that mention practice, progress, or wanting more content. Show username + comment.]*

*[Embed 2–3 thumbnails of viral Basscally videos with view counts visible — e.g., "412k views", "230k views"]*

**Stat strip:**
**90,000+** TikTok followers  |  **10,000+** Instagram followers  |  **Avg. video views: 20k–400k**

---

### Section 6 — Why $1.50?

**Heading:**
## Why $1.50?

Because practice shouldn't cost a meal.

Most bass platforms cost $20, $30, $50 a month — gatekeeping serious players behind serious money. We built Basscally Club for every bassist with internet, anywhere on Earth.

Cancel anytime. Keep everything you've already downloaded.

---

### Section 7 — Founding member offer

**Heading:**
## 🔓 Founding Member Offer

The first 500 members lock in **$1.50/month for life**.

After that, the price goes up.

**CTA button:**
`Become a Founding Member — $1.50/month`

**Small text below:**
*{{founding_members_remaining}} spots left*  *(or remove if you'd rather not show live counter at MVP)*

---

### Section 8 — FAQ

**Heading:**
## Frequently Asked Questions

**Q: What exactly do I get in the Club?**
A: A new bass practice drop every 3 days — either a bass-less cover, a groove, a fill, or a challenge. Plus the weekly bass-less version of whatever song we covered that week on TikTok. All audio files, downloadable.

**Q: How often is new content released?**
A: Every 3 days, like clockwork. About 10 new drops per month.

**Q: Can I cancel anytime?**
A: Yes. One click in your dashboard. You keep access until the end of your paid period.

**Q: Do I need to be an advanced player?**
A: No. Every drop is tagged Beginner, Intermediate, or Advanced. Start where you are.

**Q: I'm not in the UK or US. Does this work for me?**
A: Yes. We accept payments globally through Lemon Squeezy. Members are joining from Africa, Europe, Asia, Latin America, and beyond.

**Q: Can I download the files or only stream?**
A: Download. They're yours to practice with anywhere, online or offline.

**Q: Is this taught by Chris?**
A: Yes. Chris produces every drop. Same player you see on TikTok, just now with structured practice material.

**Q: What if I don't like it?**
A: Cancel anytime. We don't lock you in. We earn your $1.50 every month.

---

### Section 9 — Final CTA

**Heading:**
## Stop scrolling. Start practicing.

For less than a coffee, get a new bass practice drop every 3 days.

**Button:**
`Join Basscally Club — $1.50/month`

---

### Footer

```
Basscally Club
A bass practice membership.

[TikTok icon]  [Instagram icon]  [YouTube icon if exists]
hello@basscally.club  |  Contact

Terms of Service  |  Privacy Policy  |  Refund Policy
© 2026 Basscally. All rights reserved.
```

---

## Copy principles applied

1. **Headline does one job** — states the offer + price in one line.
2. **Subhead does the second job** — explains what you get + cadence.
3. **CTA includes price** — removes the "wait, how much?" friction.
4. **Every section has a CTA escape hatch** — sticky nav button is always visible.
5. **No marketing fluff** — "practice shouldn't cost a meal" earns its place; nothing else preaches.
6. **Global tone, no US/UK assumption** — explicit in FAQ and Section 6.
7. **Founding member offer = urgency without lying** — first 500 is a real cap.
8. **Social proof uses what you already have** — 90k TikTok, real comments. No fake testimonials.

---

## Visual / brand notes

- **Primary CTA colour:** make it pop against the rest of the page. Pick from Basscally's existing brand palette — if there isn't one, default to a warm, bass-feeling colour (deep amber, electric blue, or signature red).
- **Hero background:** dark works for music brands. Subtle texture or low-volume bass waveform animation.
- **Typography:** one display font for headings (something with character — Inter, Satoshi, or a slab serif like Recoleta), one clean sans for body (Inter or system stack).
- **No stock imagery of generic guitarists.** Use real Basscally TikTok stills or none at all.
- **Mobile-first.** ~70% of traffic from TikTok will be mobile. Test every CTA at thumb-reach height.

---

## Conversion mechanics to enable

- **One CTA destination:** every "Join" button → same Lemon Squeezy checkout URL
- **UTM tracking on bio links:** `?utm_source=tiktok&utm_medium=bio` etc., so you know where conversions came from
- **Sticky mobile CTA:** always-visible bottom bar on mobile with "Join — $1.50/mo"
- **Exit-intent (desktop only, Phase 2):** modal offering email capture if user goes to close tab
- **Page speed target:** Lighthouse score 90+ on mobile

---

*End of landing page spec. Pair with the Cursor/Codex build prompt to execute.*
